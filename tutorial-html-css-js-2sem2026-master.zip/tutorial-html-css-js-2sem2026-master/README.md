# Tópicos Importantes de CARWEB1

- Qual a estrutura básica de um código html?
- Para que serve o Doctype em um documento html?
- Qual a diferença do CSS externo, interno e inline?
- Qual é a largura e altura padrão de uma div?
- Flexbox (display: flex, justify-content, align-items, flex-direction, gap)
- O que são tags Semânticas?
- Como centralizar uma div?
- Os seletores div#logo ou p.active para classes e ids são válidos? O que eles indicam?
- Para que serve e como usar o colspan e rowspan nas tabelas?
- Quais elementos de formulários são input (type) e quais não são?

### HTML

- Elementos (atributos): 
    - html, head, title, body
    - link (rel, href)
    - h1...h6, p, span
    - img (src, alt)
    - (style)
    - id vs class
    - tags semânticas: header, nav, aside, footer, main, section, article
    - Listas ul, ol, li
    - Tabelas: table, tr, th, td (colspan, rowspan)
    - Formulários: label, select, textarea, input (type: text, password, radio, checkbox, submit) 

### CSS

- Propriedades CSS
    - background-color
    - color
    - width, min-width, max-width
    - height, min-height, max-height
    - border-radius
    - display: flex
        - flex-direction: row / column;
        - gap
        - justify-content
        - align-items
    - margin
    - padding
    - border-color, border-width, border-style
    - border: 1px solid #345659

- Seletores CSS
    - Elementos (body), (header), (h1), (p)
    - , "e" (html, body)
    - \# para id e . para class (#logo), (.wrapper)
    - \> para Descendente direto (body > header)
    - Elemento específico de id ou class (div.wrapper), (div#logo), (a.active)
    - Descendente (div .wrapper h1)
    - Selecionar por Atributo e valor (input[type="submit"])

- Revisão dia 21/09
- Avaliação 1 dia 28/09